<section class="content-header">
  <h1>
    <i class="fa fa-folder-o icon-title"></i>Listado de Pacientes

    <a class="btn btn-primary btn-social pull-right" href="?module=new_pacientes&form=add" title="Agregar" data-toggle="tooltip">
      <i class="fa fa-plus"></i> Agregar Paciente
    </a>
  </h1>

</section>


<section class="content">
  <div class="row">
    <div class="col-md-12">

    <?php  

    if (empty($_GET['alert'])) {
      echo "";
    } 
  
    elseif ($_GET['alert'] == 1) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
             Nuevos datos del paciente ha sido  agregado correctamente.
            </div>";
    }

    elseif ($_GET['alert'] == 2) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
             Datos del Paciente se modificaron correctamente.
            </div>";
    }

    elseif ($_GET['alert'] == 3) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
            Se eliminaron los datos del Paciente.
            </div>";
    }
    ?>

      <div class="box box-primary">
        <div class="box-body">
    
          <table id="dataTables1" class="table table-bordered table-striped table-hover">
      
            <thead>
              <tr>
                
               <th class="center">N°</th>
               <th class="center">N° Documento</th>
                 <th class="center">Nombres</th>
                 <th class="center">Edad</th>
                  <th class="center">Telefono</th>
                <th class="center">Direccion</th>
                <th class="center">Email</th>
                <th class="center">Genero</th>
                <th class="center">Acciones</th>               
                 
              </tr>
            </thead>
            <tbody>
            <?php  
            $no = 1;

          /*  $query = mysqli_query($mysqli, "SELECT codigo,nombre,precio_compra,precio_venta,unidad,stock FROM medicamentos ORDER BY codigo DESC")
                                            or die('error: '.mysqli_error($mysqli));*/
            $query = mysqli_query($mysqli, "SELECT id, documento, nombres, edad, telefono, email, direccion, genero, referido, peso, talla, fecha_nac
                FROM medisys.pacientes ORDER BY 2 ASC")
                                            or die('error: '.mysqli_error($mysqli));

            while ($data = mysqli_fetch_assoc($query)) { 
                  $genero = (($data['genero']=='1') ? 'FEMENINO': 'MASCULINO');

              echo "<tr>
                      <td width='30' class='center'>$data[id]</td>
                      <td width='80' class='center'>$data[documento]</td>
                      <td width='180'>$data[nombres]</td>
                      <td width='100' align='right'>$data[edad]</td>
                      <td width='100' align='right'>$data[telefono]</td>
                      <td width='80' align='right'>$data[direccion]</td>  
                      <td width='80' align='right'>$data[email]</td>    
                      <td width='80' align='right'>$genero</td>                     
                      <td class='center' width='80'>
                        <div>
                          <a data-toggle='tooltip' data-placement='top' title='Modificar' style='margin-right:5px' class='btn btn-primary btn-sm' href='?module=pacientes&form=edit&id=$data[id]'>
                              <i style='color:#fff' class='glyphicon glyphicon-edit'></i>
                          </a>";
            ?>
                          <a data-toggle="tooltip" data-placement="top" title="Eliminar" class="btn btn-danger btn-sm" href="modules/pacientes/proses.php?act=delete&id=<?php echo $data['id'];?>" onclick="return confirm('estas seguro de eliminar <?php echo $data['nombre']; ?> ?');">
                              <i style="color:#fff" class="glyphicon glyphicon-trash"></i>
                          </a>
            <?php
              echo "    </div>
                      </td>
                    </tr>";
              $no++;
            }
            ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!--/.col -->
  </div>   <!-- /.row -->
</section><!-- /.content