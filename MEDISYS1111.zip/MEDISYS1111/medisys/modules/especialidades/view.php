<section class="content-header">
  <h1>
    <i class="fa fa-folder-o icon-title"></i>Listado de Especialidades

    <a class="btn btn-primary btn-social pull-right" href="?module=new_especialidad&form=add" title="Agregar Especialidad" data-toggle="tooltip">
      <i class="fa fa-plus"></i> Agregar Especialidad
    </a>
  </h1>

</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">

    <?php  

    if (empty($_GET['alert'])) {
      echo "";
    } 
  
    elseif ($_GET['alert'] == 1) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
             Nuevos datos de la especialidad ha sido  agregado correctamente.
            </div>";
    }

    elseif ($_GET['alert'] == 2) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
             Datos de la especialidad se modificaron correctamente.
            </div>";
    }

    elseif ($_GET['alert'] == 3) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Exito!</h4>
            Se eliminaron los datos de la especialidad.
            </div>";
    }
    ?>

      <div class="box box-primary">
        <div class="box-body">
    
          <table id="dataTables1" class="table table-bordered table-striped table-hover">
      
            <thead>
              <tr>
                
               <th class="center">N°</th>
               <th class="center">Codigo</th>
                 <th class="center">Nombre</th>
                 <th class="center">estatus</th>
                  <th class="center">fecha</th>             
                <th class="center">Acciones</th>               
                 
              </tr>
            </thead>
            <tbody>
            <?php  
            $no = 1;

          /*  $query = mysqli_query($mysqli, "SELECT codigo,nombre,precio_compra,precio_venta,unidad,stock FROM medicamentos ORDER BY codigo DESC")
                                            or die('error: '.mysqli_error($mysqli));*/
            $query = mysqli_query($mysqli, "SELECT id, codigo,nombre,estatus,fecha FROM medisys.especialidades ORDER BY id DESC")
                                            or die('error: '.mysqli_error($mysqli));

            while ($data = mysqli_fetch_assoc($query)) { 
                  $estatus = (($data['estatus']=='1') ? 'ACTIVO': 'INACTIVO');

              echo "<tr>
                      <td width='30' class='center'>$data[id]</td>
                      <td width='80' class='center'>$data[codigo]</td>
                      <td width='180' class='center'>$data[nombre]</td>
                      <td width='100' align='center'>$estatus</td>
                      <td width='100' align='center'>$data[fecha]</td>
                                   
                      <td class='center' width='80'>
                        <div>
                          <a data-toggle='tooltip' data-placement='top' title='Modificar' style='margin-right:5px' class='btn btn-primary btn-sm' href='?module=pacientes&form=edit&id=$data[id]'>
                              <i style='color:#fff' class='glyphicon glyphicon-edit'></i>
                          </a>";
            ?>
                          <a data-toggle="tooltip" data-placement="top" title="Eliminar" class="btn btn-danger btn-sm" href="modules/pacientes/proses.php?act=delete&id=<?php echo $data['id'];?>" onclick="return confirm('estas seguro de eliminar <?php echo $data['nombre']; ?> ?');">
                              <i style="color:#fff" class="glyphicon glyphicon-trash"></i>
                          </a>
            <?php
              echo "    </div>
                      </td>
                    </tr>";
              $no++;
            }
            ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!--/.col -->
  </div>   <!-- /.row -->
</section><!-- /.content